export const educationData = [
    {
        id: 1,
        institution: 'Marble Hills Middle School',
        course: 'Higher Secondary Education',
        startYear: '2007',
        endYear: '2015'
    },
    {
        id: 2,
        institution: 'Somerset School of Science',
        course: 'Bachelor of Technology',
        startYear: '2015',
        endYear: '2019'
    },
    {
        id: 3,
        institution: 'Hawking University, Cambridge',
        course: 'Master of Technology',
        startYear: '2019',
        endYear: 'Present'
    },
]