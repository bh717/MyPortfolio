export const contactsData = {
    email: 'janedoe.test@gmail.com',
    phone: '+915588776600',
    address: 'Menlo Park, California, United States - 673822 ',

    sheetAPI: ''
}